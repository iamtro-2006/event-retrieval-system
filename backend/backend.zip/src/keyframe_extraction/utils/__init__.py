# keyframe_extraction utils
