# keyframe_extraction pipeline
