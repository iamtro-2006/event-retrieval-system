# embedding_extraction models
