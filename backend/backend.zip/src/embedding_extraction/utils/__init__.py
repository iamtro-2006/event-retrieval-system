# embedding_extraction utils
