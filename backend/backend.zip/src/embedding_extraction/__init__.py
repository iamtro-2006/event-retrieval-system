# embedding_extraction package
