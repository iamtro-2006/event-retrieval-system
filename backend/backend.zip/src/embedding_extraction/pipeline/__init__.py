# embedding_extraction pipeline
