# ocr_extraction utils
