# ocr_extraction utils
